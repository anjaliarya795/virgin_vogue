
  <section class="products px-5 text-center " id="products">
        <div class="row" >
          <div class="col-lg-7 col-sm-12 mt-5 mx-auto text-center" style="margin: 0 auto 0;">
            <h1 >| Our Handwriting</h1>
          </div>
          <div class="col-lg-7 col-sm-12 mt-5 mx-auto text-center" style="margin: 0 auto 0;">
            <hr class="mb-5" style="height: 3px; color: yellow;">
            <div id="products_carousel" class="carousel slide pro-img mx-auto" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="3" aria-label="Slide 4"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="4" aria-label="Slide 5"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="5" aria-label="Slide 6"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="6" aria-label="Slide 7"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="7" aria-label="Slide 8"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="8" aria-label="Slide 9"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="9" aria-label="Slide 10"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="10" aria-label="Slide 11"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="11" aria-label="Slide 12"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="12" aria-label="Slide 13"></button>
                <button type="button indicators" data-bs-target="#products_carousel" data-bs-slide-to="13" aria-label="Slide 14"></button>
                
              </div>
                <div class="carousel-inner " >
                    <div class="carousel-item active">
                      <img class="d-block w-100 pro-img" src="assets/img/products/blue_bag.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/brown_bag.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/belts.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/green_bag.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/grey_bag.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/hand_purse.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/white_bag.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/cuff-link-box-1.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/cuff-link-box-2.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/dapper-cufflink-box-1.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/dapper-cufflink-box2-1.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/earphone_bags.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/covers_2.jpg" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100 pro-img" src="assets/img/products/covers_3.jpg" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#products_carousel" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <div class="visually-hidden mt-5">Previous</div>
                </button>
                <button class="carousel-control-next rounded-5" type="button" data-bs-target="#products_carousel" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
            </div>
          </div>

        </div>
     
      

  </section>
