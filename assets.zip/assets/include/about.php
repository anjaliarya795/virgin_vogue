        <div class="row mb-5" id="about">
          <div class="col-lg-8  pt-4 pt-lg-0 order-2 order-lg-1 text-center content ">
            <h1>Who are we</h1>

            <hr class="mb-5" style="height: 3px; color: yellow;">
              <div class="small d-block d-sm-none lh-1 fw-light">
                <p>
                  Virgin Vogue was established in 2018 with a vision to deliver fresh and modish fashion to the world.
                </p>
                <p>
                  We have the experience and expertise to manufacture a variety of leather products – Bags, Wallets, Belts, Caps, Tech Accessories, Pet Accessories and Stationary. We offer a wide range of techniques- print, embroidery, weaving, patina, burnishing, washed look, hand tooling and laser work etc.
                </p>
                <p>
                  Our sourcing teams can procure a vast range of leathers, fabrics, trims, accessories, packaging materials as per our customers’ requirements and specifications.
                </p>
                <p>
                  Our customers including retailers, import agents, mail-order/catalog, and e-commerce fashion companies have remained our partners since our inception and have grown with our reliable and consistent performance. Our commitment is to deliver what we promise with an excellent level of service – high-quality, on-time.
                </p>
                <p>
                  Our goal is to meet all requirements to an absolute level of satisfaction, starting from sampling, production to delivery.
                </p>
                <p style="color: #f3cd22;">
                  We promise, you will appreciate every product you see and touch.
                </p>
              </div>
              <div class="d-none d-sm-block">
                <p>
                  Virgin Vogue was established in 2018 with a vision to deliver fresh and modish fashion to the world.
                </p>
                <p>
                  We have the experience and expertise to manufacture a variety of leather products – Bags, Wallets, Belts, Caps, Tech Accessories, Pet Accessories and Stationary. We offer a wide range of techniques- print, embroidery, weaving, patina, burnishing, washed look, hand tooling and laser work etc.
                </p>
                <p>
                  Our sourcing teams can procure a vast range of leathers, fabrics, trims, accessories, packaging materials as per our customers’ requirements and specifications.
                </p>
                <p>
                  Our customers including retailers, import agents, mail-order/catalog, and e-commerce fashion companies have remained our partners since our inception and have grown with our reliable and consistent performance. Our commitment is to deliver what we promise with an excellent level of service – high-quality, on-time.
                </p>
                <p>
                  Our goal is to meet all requirements to an absolute level of satisfaction, starting from sampling, production to delivery.
                </p>
                <p style="color: #f3cd22;">
                  We promise, you will appreciate every product you see and touch.
                </p>
              </div>
          </div>
        </div>
      