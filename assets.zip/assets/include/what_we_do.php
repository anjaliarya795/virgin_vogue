        <div class="row mx-auto" id="wwd">
          <div class="col-lg-7 mt-lg-5 text-center" style="margin: 0 auto 0;">
            <h1 style="  color: #ffffff;">What we do</h1>
            <hr class="mb-5" style="height: 3px; color: yellow;">
            <div id="whatwedo" class="carousel slide whatwedo-img  mt-5 mx-auto" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="2" aria-label="Slide 3"></button>
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="3" aria-label="Slide 4"></button>
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="4" aria-label="Slide 5"></button>
                <button type="button indicators" data-bs-target="#whatwedo" data-bs-slide-to="5" aria-label="Slide 6"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="assets/img/what_we_do/whatwedo-1.jpg" class="d-block w-100 whatwedo-img" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="assets/img/what_we_do/whatwedo-2.jpg" class="d-block w-100 whatwedo-img" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="assets/img/what_we_do/whatwedo-3.jpg" class="d-block w-100 whatwedo-img" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="assets/img/what_we_do/whatwedo-4.jpg" class="d-block w-100 whatwedo-img" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="assets/img/what_we_do/whatwedo-5.jpg" class="d-block w-100 whatwedo-img" alt="...">
                </div>
                <!-- <div class="carousel-item">
                  <img src="assets/img/what_we_do/whatwedo-6.jpg" class="d-block w-100" alt="...">
                </div> -->
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#whatwedo" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <div class="visually-hidden">Previous</div>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#whatwedo" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
