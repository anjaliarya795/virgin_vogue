    <section id="p-model" class="p-model">
      <div>
  
        <div class="row">
  
          <div class=" box col-lg-12">
  
            <div>
              <h1>| Our Production Model</h1>
            
              <h6>Fast turnaround</h6>
              
              <h6>Designed and built with care</h6>
                        
              <h6>Produced in state-of-the-art facilities</h6>
            
              <h6>Quality and performance ensured</h6>
            
              <h6>100% satisfied customers</h6>
  
          </div>
  
        </div>
  
      </div>
      
    </section>