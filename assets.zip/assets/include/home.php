<section id="home" class="d-flex align-items-center" >
    <div class=" container-fluid px-5 position-relative"  >
      
        <div class="row px-5 d-none d-xxl-block position-absolute end-50" >
          
          <div class="col-12 ">
                <h1 style="font-size:60px; margin-top:300px">Buy from someone who <span>cares.</span></h1>
          </div>
          
        </div>
        <div class="row d-none d-sm-block d-xxl-none" >
          
          <div class="col-12 ">
                <h1 style="font-size:50px; margin-top:300px">Buy from someone who <span>cares.</span></h1>
          </div>
          
        </div>
        <div class="row d-block d-sm-none" >
          
          <div class="col-12 ">
                <h1 style="font-size:30px; margin-top:100px">Buy from someone who <span>cares.</span></h1>
          </div>
          
        </div>
        
    </div>
  </section>

